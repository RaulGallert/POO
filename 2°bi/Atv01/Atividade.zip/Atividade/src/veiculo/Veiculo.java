package veiculo;

public class Veiculo {
	public int velocidade;
	public boolean status;
	
	public void ligar() {
		status = true;
	}
	
	public void desligar() {
		status = false;
		velocidade = 0;
	}
	
	public String mostrarStatus() {
		String mostrar = "O veicula está ligado? " + status + "\nVelocidade do veiculo: " + velocidade;
		return mostrar;
	}
	
	public void acelerar(){
		velocidade++;
	}
}
