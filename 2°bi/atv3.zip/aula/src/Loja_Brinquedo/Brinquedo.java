package Loja_Brinquedo;

public class Brinquedo {
	private String nome;
	private String faixaEtaria;
	private float preco;
	
	public Brinquedo() {}
	public Brinquedo(String nome) {
		this.nome = nome;
	}
	public Brinquedo(String nome, float preco) {
		this.nome = nome;
		this.preco = preco;
	}
	public void setFaixaEtaria(String faixaEtaria) {
		if (faixaEtaria == "0 a 2" || faixaEtaria == "3 a 5" || faixaEtaria == "6 a 10" || faixaEtaria == "acima de 10") {
			this.faixaEtaria = faixaEtaria;
		} else {
			System.out.println("As faixaetaria aceitas são: “0 a 2”, “3 a 5”, “6 a 10” e “acima de 10”.");
		}
	}
	public void mostrar() {
		System.out.println("Nome: " + nome + "\nFaixa Etaria: " + faixaEtaria + "\nPreço: " + preco);
	}
}
