package Atv02;

public class TestePessoa {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa();
		
		p1.setEndereco("Casa, 235, Rua Paulista");
		p1.setNome("Roberto");
		System.out.println("Nome: " + p1.getNome() + "\nEndereço: " +p1.getndereco());
	}

}
