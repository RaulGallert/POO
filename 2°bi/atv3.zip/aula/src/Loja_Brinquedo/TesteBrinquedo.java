package Loja_Brinquedo;

public class TesteBrinquedo {

	public static void main(String[] args) {
		Brinquedo b1 = new Brinquedo();
		Brinquedo b2 = new Brinquedo("Bola");
		Brinquedo b3 = new Brinquedo("Bola",10.5f);
		
		b1.setFaixaEtaria("0 a 1");
		b2.setFaixaEtaria("acima de 10");
		b3.setFaixaEtaria("3 a 5");
		
		b1.mostrar();
		b2.mostrar();
		b3.mostrar();

	}

}
