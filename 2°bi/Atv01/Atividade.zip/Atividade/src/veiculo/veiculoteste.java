package veiculo;

public class veiculoteste {

	public static void main(String[] args) {
		Veiculo vc1 = new Veiculo();
		vc1.status = false;
		vc1.velocidade = 0;
		
		vc1.ligar();
		vc1.acelerar();
		vc1.acelerar();
		vc1.acelerar();
		vc1.acelerar();
		vc1.acelerar();
		System.out.println(vc1.mostrarStatus());
		vc1.desligar();
		System.out.println(vc1.mostrarStatus());

	}

}
